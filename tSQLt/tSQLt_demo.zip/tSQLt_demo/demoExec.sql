EXEC tSQLt.Run 'testFinancialApp';
